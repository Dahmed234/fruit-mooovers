<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tilemap_packed" tilewidth="16" tileheight="16" tilecount="136" columns="17">
 <image source="../Default/Tilemap/tilemap_packed.png" width="272" height="128"/>
</tileset>
